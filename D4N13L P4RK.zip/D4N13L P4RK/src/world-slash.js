require('dotenv').config();
const { REST, Routes, ApplicationCommandType } = require('discord.js');

const commands =  [
    {
        name: 'ping',
        description: 'First command of any bot!'
    },

    {
        name: 'matchup',
        description: 'Have two characters duke it out!',
        options: [
            {
            name: 'character1',
            description: 'The first character/team in the fight!',
            type: 3,
            required: true,   
            maxLength: 25,
     }, 
     {
        name: 'character2',
        description: 'The second character/team in the fight!',
        type: 3,
        required: true, 
        maxLength: 25,  
 }, 
    ]
    },
    {
    name: 'deathbattle',
        description: 'Pit two characters against each other in a gruesome death match!',
        options: [
            {
        name: 'dbfighter1',
        description: 'The first character in the fight!',
        type: 3,
        required: true,
        maxLength: 25,
            },
           {
        name: 'dbfighter2',
        description: 'The second character in the fight!',
        type: 3,
        required: true,
        maxLength: 25,
           },
           {
        name: 'weapon1',
        description: "The first character's weapon!",
        type: 3,
        required: true,
        maxLength: 25,
           },
           {
        name: 'weapon2',
        description: "The second character's weapon!",
        type: 3,
        required: true,
        maxLength: 25,
           },
           {
        name: 'location',
        description: 'The location of the fight!',
        type: 3,
        required: true,
        maxLength: 25,
           } 
        ]
    },
    {
        name: 'powerscaling',
        description: 'Ping the channel to argue about fictional characters!',
        options: [
            {
        name: 'question',
        description: 'Your dumb and probably stupid question.',
        type: 3,
        required: true,
        maxLength: 25,
            }
        ]
    },
]

const rest = new REST({ version: '10' }).setToken(process.env.token);

(async () => {
    try{
        console.log('Registering slash commands...');

    await rest.put(
        Routes.applicationGuildCommands(
        process.env.CLIENT_ID,
        process.env.GUILD_ID),
        {body: commands}
    );
        console.log('Slash commands were registered successfully')
    } catch (error) {
        console.log(`Oh no! You fucked up! You see: ${error}!`)
    }
})();