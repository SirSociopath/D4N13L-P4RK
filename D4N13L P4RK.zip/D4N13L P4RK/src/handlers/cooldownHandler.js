// cooldownHandler.js

const cooldowns = new Map();

function startCooldown(commandName, userId, cooldownTime) {
  const endTime = Date.now() + cooldownTime;
  cooldowns.set(`${commandName}-${userId}`, endTime);
}

function isOnCooldown(commandName, userId) {
  const endTime = cooldowns.get(`${commandName}-${userId}`);
  if (!endTime || endTime < Date.now()) {
    cooldowns.delete(`${commandName}-${userId}`);
    return false;
  } else {
    return true;
  }
}

module.exports = { startCooldown, isOnCooldown };
