module.exports = async (client, GUILD_ID) => {
    let applicationCommands;
  
    if (GUILD_ID) {
      const guild = await client.guilds.fetch(GUILD_ID);
      applicationCommands = guild.commands;
    } else {
      applicationCommands = await client.application.commands;
    }
  
    await applicationCommands.fetch();
    return applicationCommands;
  };