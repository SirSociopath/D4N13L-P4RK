const { ApplicationCommandOptionType } = require('discord.js');
const { Collection } = require('discord.js');
const scalingCooldowns = new Collection();
const { isOnCooldown, startCooldown } = require(process.cwd() + "/src/handlers/cooldownHandler.js");

module.exports = {
    name: 'deathbattle',
    description: 'Pit characters against each other in a gruesome death match!',
    options: [ {
        name: "dbfighter1",
        description: "The first character/team in the death battle!",
        required: true,
        type: ApplicationCommandOptionType.String,
        maxLength: 25,
        
    },
    {
        name: "dbfighter2",
        description: "The second character/team in the death battle!",
        required: true,
        type: ApplicationCommandOptionType.String,
        maxLength: 25,
        
    },
    {
        name: "weapon1",
        description: "The first character's weapon!",
        required: true,
        type: ApplicationCommandOptionType.String,
        maxLength: 25,
        
    },
    {
        name: "weapon2",
        description: "The second character's weapon!",
        required: true,
        type: ApplicationCommandOptionType.String,
        maxLength: 25,
        
    },
    {
        name: "location",
        description: "The location of the death battle!",
        required: true,
        type: ApplicationCommandOptionType.String,
        maxLength: 25,
        
    }],
  

    callback: (client, interaction) => {
        const userId = interaction.guild.id;
        
        if (isOnCooldown('deathbattle', userId)) {
            const cooldownAmount = 30 * 60 * 1000; // 30 minutes in milliseconds

// Check if the guild has a cooldown entry
if (scalingCooldowns.has(interaction.guild.id)) {
    const expirationTime = scalingCooldowns.get(interaction.guild.id) + cooldownAmount;

    if (now < expirationTime) {
        const timeLeft = (expirationTime - now) / 1000;
        return interaction.reply(`The scaling commands are on cooldown. Please wait ${timeLeft.toFixed(1)} more seconds.`);
    }
}

// Store the timestamp of this command's usage
scalingCooldowns.set(interaction.guild.id, now);
            interaction.reply({ content: "The server is still on cooldown for pings!", ephemeral: true });
            return;
        }

        const firstDBCharacter = interaction.options.getString("dbfighter1");
        const secondDBCharacter = interaction.options.getString("dbfighter2");
        const location = interaction.options.getString("location");
        const weaponFirst = interaction.options.getString("weapon1");
        const weaponSecond = interaction.options.getString("weapon2");
        
        interaction.reply({ 
            content: `<@&1004005579246817370> It's a gruesome death battle with ${firstDBCharacter} using ${weaponFirst} versus ${secondDBCharacter} using ${weaponSecond} at ${location}!`,
            in_channel: true
        });
        startCooldown('matchup', userId, 30 * 60 * 1000); // 30 minutes cooldown
        startCooldown('deathbattle', userId, 30 * 60 * 1000); // Assuming the same cooldown for all commands
        startCooldown('powerscaling', userId, 30 * 60 * 1000); // Assuming the same cooldown for all commands
    },
  };