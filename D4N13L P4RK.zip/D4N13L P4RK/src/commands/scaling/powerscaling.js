const { ApplicationCommandOptionType } = require("discord.js");
const { isOnCooldown, startCooldown } = require(process.cwd() + "/src/handlers/cooldownHandler.js");

module.exports = {
    name: 'powerscaling',
    description: 'Ping the whole channel so you guys can argue about fictional characters!',
    options: [ {
        name: "question",
        description: "The first character/team in the fight!",
        required: true,
        type: ApplicationCommandOptionType.String,
        maxLength: 40,
        
    
    }
    
],


    callback: (client, interaction) => {
        const userId = interaction.user.id;
        
        if (isOnCooldown('powerscaling', userId)) {
            interaction.reply({ content: "The server is still on cooldown for pings!", ephemeral: true });
            return;
        }
        const question = interaction.options.getString("question");
interaction.reply({ content: `<@&1004005579246817370> So, a moron asks ${question}?`, in_channel: true});

        startCooldown('matchup', userId, 30 * 60 * 1000); // 30 minutes cooldown
        startCooldown('deathbattle', userId, 30 * 60 * 1000); // Assuming the same cooldown for all commands
        startCooldown('powerscaling', userId, 30 * 60 * 1000); // Assuming the same cooldown for all commands

    },
};