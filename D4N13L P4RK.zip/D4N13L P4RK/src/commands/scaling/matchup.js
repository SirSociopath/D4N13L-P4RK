const { ApplicationCommandOptionType } = require('discord.js');
const { isOnCooldown, startCooldown } = require(process.cwd() + "/src/handlers/cooldownHandler.js");

module.exports = {
    name: 'matchup',
    description: 'Ask about the outcome of two characters duking it out!',
    options: [ {
        name: 'character1',
        description: "The first character/team in the fight!",
        required: true,
        type: ApplicationCommandOptionType.String,
        maxLength: 25,
        
    },
    {
        name: 'character2',
        description: "The second character/team in the fight!",
        required: true,
        type: ApplicationCommandOptionType.String,
        maxLength: 25,
        
    }
],

    callback: (client, interaction) => {
        const userId = interaction.user.id;
        
        if (isOnCooldown('matchup', userId)) {
            interaction.reply({ content: "The server is still on cooldown for pings!", ephemeral: true });
            return;
        }

            const firstCharacter = interaction.options.getString('character1');
            const secondCharacter = interaction.options.getString('character2');
            interaction.reply({ content: `<@&1004005579246817370> So it's ${firstCharacter} versus ${secondCharacter}! Who wins?`, in_channel: true });

    
            startCooldown('matchup', userId, 30 * 60 * 1000); // 30 minutes cooldown
            startCooldown('deathbattle', userId, 30 * 60 * 1000); // Assuming the same cooldown for all commands
            startCooldown('powerscaling', userId, 30 * 60 * 1000); // Assuming the same cooldown for all commands            
    },

};
